import "package:friendsapp/utils/Utils.dart";

class User {
  int id;
  String fullname;
  String phone;
  String lastname;



  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      columnFullName: fullname,
      columnPhone: phone,
      columnLastName: lastname
    };
    if (id != null) {
      map[columnId] = id;
    }
    return map;
  }
  User();

  User.fromMap(Map<String, dynamic> map) {
    id = map[columnId];
    fullname = map[columnFullName];
    phone = map[columnPhone];
    lastname = map[columnLastName];
  }
}