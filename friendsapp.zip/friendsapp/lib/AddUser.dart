

import 'package:flutter/material.dart';
import 'package:friendsapp/database/database_helper.dart';
import 'package:friendsapp/utils/Utils.dart';

import 'model/User.dart';

class AddUser1 extends StatelessWidget {

  bool flag = false;
  bool insertItem = false;
  final teNameController = TextEditingController();
  final tePhoneController = TextEditingController();
  final lastnameController = TextEditingController();
  List<User> items = new List();
  List<User> values;
  final GlobalKey<AnimatedListState> _listKey = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false;
  ScrollController _scrollController;


  /*onEdit(User user, int index) {
    openAlertBox(user);
  }

  openAlertBox(User user) {
    if (user != null) {
      teNameController.text = user.fullname;
      tePhoneController.text = user.phone;
      lastnameController.text = user.lastname;
      flag = true;
    } else {
      flag = false;
      teNameController.text = "";
      tePhoneController.text = "";
      lastnameController.text = "";
    }
  }*/


    @override
    Widget build(BuildContext context) {

      return Scaffold(
        appBar: AppBar(
          title: Text("Add User"),
        ),
        body: Center(
          child: Container(
            width: 300.0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      flag ? "Edit User" : "Add User",
                      style: TextStyle(fontSize: 28.0),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5.0,
                ),
                Divider(
                  color: Colors.grey,
                  height: 4.0,
                ),
                Padding(
                  padding: EdgeInsets.only(left: 20.0, right: 20.0),
                  child: Form(
                    key: _formKey,
                    // autovalidate: _autoValidate,
                    child: Column(
                      children: <Widget>[
                        TextFormField(
                          controller: teNameController,
                          keyboardType: TextInputType.text,
                          decoration: InputDecoration(
                            hintText: "Add First Name",
                            fillColor: Colors.grey[300],
                            border: InputBorder.none,
                          ),
                          validator: validateName,
                          onSaved: (String val) {
                            teNameController.text = val;
                          },
                        ),
                        TextFormField(
                          keyboardType: TextInputType.text,
                          controller: lastnameController,
                          decoration: InputDecoration(
                            hintText: "Add Last Name",
                            fillColor: Colors.grey[300],
                            border: InputBorder.none,
                          ),
                          maxLines: 1,
                          validator: validateName,
                          onSaved: (String val) {
                            lastnameController.text = val;
                          },
                        ),
                        TextFormField(
                          keyboardType: TextInputType.phone,
                          controller: tePhoneController,
                          decoration: InputDecoration(
                            hintText: "Add Phone",
                            fillColor: Colors.grey[300],
                            border: InputBorder.none,
                          ),
                          maxLines: 1,
                          validator: validateMobile,
                          onSaved: (String val) {
                            tePhoneController.text = val;
                          },
                        ),

                      ],
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                   addUser();
                   // Navigator.of(context).pop();
                  },
                  child: Container(
                    padding: EdgeInsets.only(top: 20.0, bottom: 20.0),
                    decoration: BoxDecoration(
                      color: Colors.blue,
                    ),
                    child: Text(
                      flag ? "Edit User" : "Add User",
                      style: TextStyle(color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }


  /// Validation Check
  String validateName(String value) {
    if (value.length < 3)
      return 'Name must be more than 2 charater';
    else if (value.length > 30) {
      return 'Name must be less than 30 charater';
    } else
      return null;
  }

  String validateMobile(String value) {
    Pattern pattern = r'^[0-9]*$';
    RegExp regex = new RegExp(pattern);
    if (value.trim().length != 10)
      return 'Mobile Number must be of 10 digit';
    else if (value.startsWith('+', 0)) {
      return 'Mobile Number should not contain +91';
    } else if (value.trim().contains(" ")) {
      return 'Blank space is not allowed';
    } else if (!regex.hasMatch(value)) {
      return 'Characters are not allowed';
    } else
      return null;
  }
  ///add User Method
  addUser() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      var user = User();
      user.fullname = teNameController.text;
      user.phone = tePhoneController.text;
      user.lastname = lastnameController.text;
      var dbHelper = Helper();
      dbHelper.insert(user).then((value) {
        teNameController.text = "";
        tePhoneController.text = "";
        lastnameController.text = "";
        //Navigator.of(context).pop("value");
       // Navigator.pop(context);
        showtoast("Successfully Added Data");
        insertItem = true;
     /*  setState(() {
          insertItem = true;
        });*/
      });
    } else {
      _autoValidate = true;
//    If all data are not valid then start auto validation.
    /*  setState(() {
        _autoValidate = true;
      });*/
    }
  }

  @override
  void initState() {
   initState();

  }

  ///edit User
  editUser(int id) {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      var user = User();
      user.id = id;
      user.fullname = teNameController.text;
      user.phone = tePhoneController.text;
      user.lastname = lastnameController.text;
      var dbHelper = Helper();
      dbHelper.update(user).then((update) {
        teNameController.text = "";
        tePhoneController.text = "";
        lastnameController.text = "";

        showtoast("Data Saved successfully");
        /*setState(() {
          flag = false;
        });*/
      });
    } else {
//    If all data are not valid then start auto validation.
      /*setState(() {
        _autoValidate = true;
      });*/
    }
  }

}