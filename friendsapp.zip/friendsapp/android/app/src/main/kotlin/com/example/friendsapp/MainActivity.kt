package com.example.friendsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
